﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EsercizioConcessionaria
{
    internal class Macchina : Prodotto
    {
        public int Cilindrata {  get; set; }
        public int VelocitaMax {  get; set; }
        public int PostiAuto { get; set; }
        public Prodotto Prodotto { get; set; }

        public override string ToString()
        {
            return base.ToString() + $"\nCilindrata: {Cilindrata} \nVelocita Massima: {VelocitaMax}km/h \nPosti Auto:{PostiAuto} \nAuto Potente: {(Potente() ? "si" : "no")}";
        }
        public bool Potente()
        {
            if (Cilindrata > 2000 && Famoso())
                return true;
            else 
               return false;
        }
    }
}
