﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Utility01;

namespace EsercizioConcessionaria
{
    internal class Menu 
    {
        public static void MenuPrincipale()
        {
            string digit = "";
            do
            {
                Console.WriteLine($"Benvenuto nella Concessionaria di Generation! \nDigita: \n1.Per V");
                digit = Console.ReadLine();
                switch (digit)
                {
                    case "1":
                        ListaProdottiVecchi();
                        break;
                    case "2":
                        Console.WriteLine();
                        break;
                    case "3":
                        Console.WriteLine();
                        break;
                    case "4":
                        Console.WriteLine();
                        break;
                    case "5":
                        Console.WriteLine();
                        break;
                    case "6":
                        Console.WriteLine();
                        break;
                    case "7":
                        Console.WriteLine();
                        break;
                    case "8":
                        Console.WriteLine();
                        break;
                    case "9":
                        Console.WriteLine();
                        break;
                    default:
                        break;
                }

            } while (digit != "0");
        }

       }
    }
}
